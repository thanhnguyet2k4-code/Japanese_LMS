# Grading and Learning Results

This package contains only the grading and results module. Copy `src/` into the root of the existing Japanese LMS repository, keeping the folder structure. Do not replace the whole project.

## Routes
- Instructor: `/instructor/grading`, `/instructor/results`
- Student: `/student/grades`
- Admin: `/admin/results`
- Result details: `/instructor/results/{id}`, `/student/results/{id}`, `/admin/results/{id}`

## Verification
Run `./mvnw test` (Windows: `mvnw.cmd test`) from the existing project root. With SQL Server running, verify an instructor can grade a submission from their own course, a student can view the grade, and access to another student's result is denied.

Changes: restrict grade form access to the assigned instructor, validate grade and feedback on the service layer, simplify repository comment, and replace browser-history navigation with role-specific links. No other member's Java files, database schema, or application configuration are changed.

Automated tests were added but could not be executed in the packaging environment because Maven distribution download was unavailable. Runtime verification with SQL Server remains required.
